package scs;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class MyTest {
	@AfterClass
	  public void afterclassExample1()
	  {
	  	 System.out.println("after CLASS");
	  }
@BeforeClass
public void beforeclassExample()
{
	 System.out.println("before CLASS");
}
	 @AfterSuite
	  public void aftersuiteExample1()
	  {
	  	 System.out.println("after suite");
	  }
@BeforeSuite
public void beforesuiteExample()
{
	 System.out.println("before suite");
}
	 @AfterTest
	  public void afterTestExample()
	  {
	  	 System.out.println("after test");
	  }
@BeforeTest
public void beforeTestExample()
{
	 System.out.println("beforetest");
}
  @Test(priority = 2)
  public void login() {
	  System.out.println("Test Case For Login");
	  
  }
  @Test(priority = 1)
  public void reg() {
	  System.out.println("Test Case For Registartion");
	  
  }
  @BeforeMethod
  public void beforemethod()
  {
	  System.out.println("before method");
  }
  @AfterMethod
  public void aftermethod()
  {
	  System.out.println("after method");
  }
 
}
