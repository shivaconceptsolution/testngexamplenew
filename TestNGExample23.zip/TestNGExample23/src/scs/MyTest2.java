package scs;

import org.testng.annotations.Test;

public class MyTest2 {
  @Test
  public void f() {
	  System.out.println("CLASS TEST 2");
  }
}
